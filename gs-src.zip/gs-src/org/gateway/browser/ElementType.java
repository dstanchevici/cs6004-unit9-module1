package org.gateway.browser;

public enum ElementType {

    none, hline, text, inputfield, button, image, server, vspace;

}
